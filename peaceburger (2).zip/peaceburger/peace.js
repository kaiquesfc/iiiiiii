const imgs = document.getElementById("img");
const img = document.querySelectorAll("#img img");
let idx = 0;

function updateCarousel() {
  imgs.style.transform = `translateX(${-idx * 100}%)`;
}

function nextSlide() {
  idx++;
  if (idx > img.length - 1) {
    idx = 0;
  }
  updateCarousel();
}


function prevSlide() {
  idx--;
  if (idx < 0) {
    idx = img.length - 1;
  }
  updateCarousel();
}

function carroussel() {
  nextSlide();
}

setInterval(carroussel, 5000);



document.addEventListener("DOMContentLoaded", function() {
  var button = document.querySelector('.back-to-top');

  window.addEventListener('scroll', function() {
      if (window.scrollY > 300) {
          button.classList.add('show');
      } else {
          button.classList.remove('show');
      }
  });

  button.addEventListener('click', function(e) {
      e.preventDefault();
      window.scrollTo({top: 0, behavior: 'smooth'});
  });
});
function nextSlide() {
  const container = document.querySelector('.container');
  container.style.transition = 'transform 0.5s ease-in-out';
  container.style.transform = 'translateX(-1442px)';
}

function prevSlide() {
  const container = document.querySelector('.container');
  container.style.transition = 'transform 0.5s ease-in-out';
  container.style.transform = 'translateX(0)';
}